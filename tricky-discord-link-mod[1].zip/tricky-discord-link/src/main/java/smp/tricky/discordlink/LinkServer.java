package smp.tricky.discordlink;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;
import org.slf4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Tiny TCP server for the Discord bot. Protocol: one JSON object per line.
 * The bot's first line must be {"type":"auth","token":"..."}.
 * Zero extra dependencies (plain java.net + the Gson that ships with Minecraft).
 */
final class LinkServer {
    private final Config config;
    private final Logger log;
    private final MinecraftServer server;

    private ServerSocket serverSocket;
    private volatile boolean running;
    private volatile Conn active;
    private final Map<UUID, Long> linkCooldown = new ConcurrentHashMap<>();

    /** One writer thread so a slow/stalled bot can never block the game thread. */
    private final ThreadPoolExecutor writer = new ThreadPoolExecutor(
            1, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>(1000),
            r -> {
                Thread t = new Thread(r, "TrickyLink-Writer");
                t.setDaemon(true);
                return t;
            },
            new ThreadPoolExecutor.DiscardPolicy());

    LinkServer(Config config, Logger log, MinecraftServer server) {
        this.config = config;
        this.log = log;
        this.server = server;
    }

    // ------------------------------------------------------------------ lifecycle

    void start() throws IOException {
        serverSocket = new ServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress(InetAddress.getByName(config.bindAddress), config.port));
        running = true;
        Thread accept = new Thread(this::acceptLoop, "TrickyLink-Accept");
        accept.setDaemon(true);
        accept.start();
        log.info("Discord link listening on {}:{}", config.bindAddress, config.port);
    }

    void stop() {
        running = false;
        writer.shutdown();
        try {
            writer.awaitTermination(2, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
        Conn c = active;
        if (c != null) c.close();
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException ignored) {
        }
    }

    boolean isBotConnected() {
        return active != null;
    }

    /** Queue an event/message for the bot. Safe to call from any thread. No-op if the bot is offline. */
    void sendToBot(JsonObject obj) {
        Conn c = active;
        if (c != null) c.send(obj);
    }

    boolean allowLink(UUID player) {
        long now = System.currentTimeMillis();
        Long last = linkCooldown.get(player);
        if (last != null && now - last < config.linkCooldownSeconds * 1000L) return false;
        linkCooldown.put(player, now);
        return true;
    }

    // ------------------------------------------------------------------ connections

    private void acceptLoop() {
        while (running) {
            try {
                Socket s = serverSocket.accept();
                Thread t = new Thread(() -> handle(s), "TrickyLink-Conn");
                t.setDaemon(true);
                t.start();
            } catch (IOException e) {
                if (running) log.warn("Accept failed: {}", e.toString());
            }
        }
    }

    private void handle(Socket s) {
        Conn conn = null;
        try (s) {
            s.setSoTimeout(5000);
            s.setTcpNoDelay(true);
            InputStream in = new BufferedInputStream(s.getInputStream());

            String first = readLine(in, 1024);
            if (first == null || !authenticate(first)) {
                log.warn("Rejected link connection from {} (bad or missing token)", s.getRemoteSocketAddress());
                Thread.sleep(1000); // slow down guessing
                return;
            }

            conn = new Conn(s, s.getOutputStream());
            Conn old = active;
            active = conn;
            if (old != null) old.close();
            conn.send(obj("type", "auth_ok"));
            log.info("Discord bot connected from {}", s.getRemoteSocketAddress());

            s.setSoTimeout(60_000); // the bot pings every ~20s
            String line;
            while (running && (line = readLine(in, config.maxLineBytes)) != null) {
                if (!line.isBlank()) handleMessage(conn, line);
            }
        } catch (SocketTimeoutException e) {
            log.info("Discord bot link timed out");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            if (running) log.debug("Link connection closed: {}", e.toString());
        } finally {
            if (conn != null) {
                conn.close();
                if (active == conn) {
                    active = null;
                    log.info("Discord bot disconnected");
                }
            }
        }
    }

    private boolean authenticate(String line) {
        try {
            JsonObject o = JsonParser.parseString(line).getAsJsonObject();
            if (!"auth".equals(str(o, "type"))) return false;
            byte[] given = str(o, "token").getBytes(StandardCharsets.UTF_8);
            byte[] expected = config.token.getBytes(StandardCharsets.UTF_8);
            return MessageDigest.isEqual(given, expected); // constant-time compare
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ bot -> Minecraft

    private void handleMessage(Conn conn, String line) {
        JsonObject msg;
        try {
            msg = JsonParser.parseString(line).getAsJsonObject();
        } catch (Exception e) {
            return;
        }
        String type = str(msg, "type");
        JsonElement id = msg.get("id");

        switch (type) {
            case "ping" -> conn.send(obj("type", "pong"));

            case "chat" -> {
                String user = clean(str(msg, "user"), 32);
                String text = clean(str(msg, "message"), 256);
                if (!text.isEmpty()) server.execute(() -> broadcastFromDiscord(user.isEmpty() ? "Discord" : user, text));
            }

            case "players" -> server.execute(() -> {
                JsonArray names = new JsonArray();
                for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                    names.add(p.getName().getString());
                }
                JsonObject r = obj("type", "players_result");
                r.add("players", names);
                r.addProperty("max", server.getPlayerList().getMaxPlayers());
                withId(r, id);
                conn.send(r);
            });

            case "playtime" -> {
                JsonObject r = obj("type", "playtime_result");
                r.addProperty("seconds", readPlaytimeSeconds(str(msg, "uuid")));
                withId(r, id);
                conn.send(r);
            }

            case "link_result" -> {
                String uuid = str(msg, "uuid");
                boolean ok = msg.has("ok") && msg.get("ok").isJsonPrimitive() && msg.get("ok").getAsBoolean();
                String text = clean(str(msg, "message"), 200);
                server.execute(() -> deliverLinkResult(uuid, ok, text));
            }

            default -> { /* ignore unknown types */ }
        }
    }

    private void broadcastFromDiscord(String user, String text) {
        Component c = Component.literal("[Discord] ").withStyle(ChatFormatting.BLUE)
                .append(Component.literal(user + ": ").withStyle(ChatFormatting.WHITE))
                .append(Component.literal(text).withStyle(ChatFormatting.GRAY));
        server.getPlayerList().broadcastSystemMessage(c, false);
    }

    private void deliverLinkResult(String uuid, boolean ok, String text) {
        try {
            ServerPlayer p = server.getPlayerList().getPlayer(UUID.fromString(uuid));
            if (p == null) return;
            p.sendSystemMessage(Component.literal(text.isEmpty() ? (ok ? "Linked!" : "Link failed.") : text)
                    .withStyle(ok ? ChatFormatting.GREEN : ChatFormatting.RED));
        } catch (IllegalArgumentException ignored) {
        }
    }

    /** Reads play time from the player's stats file. Tries the newer and older folder layouts. */
    private long readPlaytimeSeconds(String uuidStr) {
        try {
            UUID u = UUID.fromString(uuidStr);
            Path root = server.getWorldPath(LevelResource.ROOT);
            Path[] candidates = {
                    root.resolve("players").resolve("stats").resolve(u + ".json"),
                    root.resolve("stats").resolve(u + ".json")
            };
            for (Path p : candidates) {
                if (!Files.exists(p)) continue;
                JsonObject o = JsonParser.parseString(Files.readString(p)).getAsJsonObject();
                JsonObject stats = o.has("stats") ? o.getAsJsonObject("stats") : o;
                if (!stats.has("minecraft:custom")) return 0;
                JsonObject custom = stats.getAsJsonObject("minecraft:custom");
                for (String key : new String[]{"minecraft:play_time", "minecraft:play_one_minute"}) {
                    if (custom.has(key)) return custom.get(key).getAsLong() / 20L;
                }
                return 0;
            }
        } catch (Exception e) {
            log.debug("Could not read playtime: {}", e.toString());
        }
        return 0;
    }

    // ------------------------------------------------------------------ helpers

    private static String str(JsonObject o, String key) {
        JsonElement e = o.get(key);
        return e != null && e.isJsonPrimitive() ? e.getAsString() : "";
    }

    static JsonObject obj(String k, String v) {
        JsonObject o = new JsonObject();
        o.addProperty(k, v);
        return o;
    }

    private static void withId(JsonObject r, JsonElement id) {
        if (id != null && !id.isJsonNull()) r.add("id", id);
    }

    /** Strip control characters and the section sign, then limit the length. */
    private static String clean(String s, int max) {
        String t = s.replaceAll("[\\p{Cntrl}\u00a7]", "").trim();
        return t.length() > max ? t.substring(0, max) : t;
    }

    /** Reads one '\n'-terminated line, refusing lines longer than {@code max} bytes. Returns null at EOF. */
    private static String readLine(InputStream in, int max) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        int b;
        while ((b = in.read()) != -1) {
            if (b == '\n') return buf.toString(StandardCharsets.UTF_8);
            if (b == '\r') continue;
            if (buf.size() >= max) throw new IOException("line too long");
            buf.write(b);
        }
        return null;
    }

    private final class Conn {
        private final Socket socket;
        private final OutputStream out;

        Conn(Socket socket, OutputStream out) {
            this.socket = socket;
            this.out = out;
        }

        void send(JsonObject o) {
            byte[] data = (o + "\n").getBytes(StandardCharsets.UTF_8);
            writer.execute(() -> {
                try {
                    synchronized (out) {
                        out.write(data);
                        out.flush();
                    }
                } catch (IOException e) {
                    close();
                }
            });
        }

        void close() {
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }
}
