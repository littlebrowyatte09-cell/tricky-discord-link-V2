package smp.tricky.discordlink;

import com.google.gson.JsonObject;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Server-side only: players do NOT need this mod installed. */
public class TrickyDiscordLink implements ModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("tricky_discord_link");
    private static volatile LinkServer link;

    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(this::onServerStarted);
        ServerLifecycleEvents.SERVER_STOPPING.register(this::onServerStopping);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                playerEvent("join", handler.getPlayer(), null));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
                playerEvent("quit", handler.getPlayer(), null));

        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            LinkServer l = link;
            if (l == null) return;
            JsonObject o = LinkServer.obj("type", "chat");
            o.addProperty("player", sender.getName().getString());
            o.addProperty("message", message.signedContent());
            l.sendToBot(o);
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayer p) {
                playerEvent("death", p, p.getCombatTracker().getDeathMessage().getString());
            }
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("link")
                        .executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            p.sendSystemMessage(Component.literal(
                                    "Run /link in Discord to get a code, then type /link <code> here.")
                                    .withStyle(ChatFormatting.YELLOW));
                            return Command.SINGLE_SUCCESS;
                        })
                        .then(Commands.argument("code", StringArgumentType.word())
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    return runLink(p, StringArgumentType.getString(ctx, "code"));
                                }))));
    }

    private void onServerStarted(MinecraftServer server) {
        try {
            Config config = Config.load(FabricLoader.getInstance().getConfigDir().resolve("tricky-discord-link.json"), LOG);
            if (!config.tokenIsUsable()) {
                LOG.error("The token in config/tricky-discord-link.json is missing or too short (need 24+ characters). Link disabled.");
                return;
            }
            LinkServer l = new LinkServer(config, LOG, server);
            l.start();
            link = l;
            l.sendToBot(LinkServer.obj("type", "server_start"));
        } catch (Exception e) {
            LOG.error("Could not start the Discord link (is the port correct and free?)", e);
        }
    }

    private void onServerStopping(MinecraftServer server) {
        LinkServer l = link;
        if (l == null) return;
        l.sendToBot(LinkServer.obj("type", "server_stop"));
        l.stop();
        link = null;
    }

    private static void playerEvent(String type, ServerPlayer player, String message) {
        LinkServer l = link;
        if (l == null) return;
        JsonObject o = LinkServer.obj("type", type);
        o.addProperty("player", player.getName().getString());
        if (message != null) o.addProperty("message", message);
        l.sendToBot(o);
    }

    private static int runLink(ServerPlayer player, String code) {
        LinkServer l = link;
        if (l == null || !l.isBotConnected()) {
            player.sendSystemMessage(Component.literal("The Discord link is offline right now. Try again later.")
                    .withStyle(ChatFormatting.RED));
            return 0;
        }
        if (!code.matches("[A-Za-z0-9]{4,10}")) {
            player.sendSystemMessage(Component.literal("That doesn't look like a link code.").withStyle(ChatFormatting.RED));
            return 0;
        }
        if (!l.allowLink(player.getUUID())) {
            player.sendSystemMessage(Component.literal("Slow down, try again in a few seconds.").withStyle(ChatFormatting.RED));
            return 0;
        }
        JsonObject o = LinkServer.obj("type", "link");
        o.addProperty("code", code.toUpperCase());
        o.addProperty("uuid", player.getUUID().toString());
        o.addProperty("name", player.getName().getString());
        l.sendToBot(o);
        player.sendSystemMessage(Component.literal("Checking your code...").withStyle(ChatFormatting.GRAY));
        return Command.SINGLE_SUCCESS;
    }
}
