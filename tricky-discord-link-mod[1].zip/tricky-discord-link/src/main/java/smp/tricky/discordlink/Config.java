package smp.tricky.discordlink;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.HexFormat;

/** Settings stored in config/tricky-discord-link.json. */
public final class Config {
    /** Port the Discord bot connects to (your host's "Discord Connection" port). */
    public int port = 22287;
    /** Address to listen on. 0.0.0.0 = all interfaces. */
    public String bindAddress = "0.0.0.0";
    /** Shared secret. Must be identical to MC_API_TOKEN in the bot's .env. */
    public String token = "";
    /** Longest single message accepted from the bot, in bytes. */
    public int maxLineBytes = 16384;
    /** Seconds a player must wait between /link attempts. */
    public int linkCooldownSeconds = 5;

    static Config load(Path file, Logger log) throws IOException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        if (Files.notExists(file)) {
            Config fresh = new Config();
            fresh.token = randomToken();
            Files.createDirectories(file.getParent());
            Files.writeString(file, gson.toJson(fresh));
            log.info("Created {}. Copy its \"token\" into the bot's MC_API_TOKEN.", file);
            return fresh;
        }
        Config loaded = gson.fromJson(Files.readString(file), Config.class);
        return loaded == null ? new Config() : loaded;
    }

    private static String randomToken() {
        byte[] bytes = new byte[32];
        new SecureRandom().nextBytes(bytes);
        return HexFormat.of().formatHex(bytes);
    }

    boolean tokenIsUsable() {
        return token != null && token.length() >= 24;
    }
}
