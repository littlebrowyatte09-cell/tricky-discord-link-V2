# TRICKY SMP Discord Link (Fabric, Minecraft 26.2)

A **server-side only** mod. Put it on the server; players do **not** need it, so don't add it to the player modpack.

It connects the server to the Discord bot: chat bridge, join/leave/death messages, player list, playtime, and `/link` account linking.

## Install
1. Build the jar (see below) and put it in the server's `mods/` folder next to Fabric API.
2. Start the server once. It creates `config/tricky-discord-link.json` with a random `token`.
3. Copy that `token` into the bot's `.env` as `MC_API_TOKEN`, then restart the bot.
4. Check the server log for `Discord link listening on 0.0.0.0:22287` and, once the bot starts, `Discord bot connected`.

If the log says the port is in use or can't bind, set `bindAddress` in the config to the IP your host gives the server, and make sure `port` is the one labelled "Discord Connection".

## Building the jar
The easy way (nothing to install):
1. Create a free GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab, run **Build mod**, and download the `tricky-discord-link` artifact: the `.jar` inside is your mod. Ignore the `-sources.jar`.

Or locally: install JDK 25 and Gradle 9.5.1, then run `gradle build`. The jar appears in `build/libs/`.

If Gradle says it can't find the Loom plugin version, change `loom_version` in `gradle.properties` to `1.17-SNAPSHOT`.

## Commands (in game)
- `/link` shows how linking works. `/link CODE` links the player's Minecraft account to the Discord account that generated the code with `/link` in Discord.

## Config (`config/tricky-discord-link.json`)
| Key | Meaning |
|---|---|
| `port` | Port the bot connects to (22287) |
| `bindAddress` | Address to listen on (`0.0.0.0` = all) |
| `token` | Shared secret, must match the bot's `MC_API_TOKEN` |
| `maxLineBytes` | Largest message accepted from the bot |
| `linkCooldownSeconds` | Delay between `/link` attempts per player |

## Notes
- Written against Minecraft 26.2's official (unobfuscated) names and Fabric API 0.161.0+26.2. It has not been compiled or run yet, so the first build may need small fixes.
- Advancement messages aren't sent yet.
